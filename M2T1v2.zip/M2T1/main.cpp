//CSC 134
//M2L1
//Ethan Warren
//01/22/18

#include <iostream>

using namespace std;

int main()
{
    //Variables
    string qInputCall;
    string qInputNam;
    double qInputRat;
    int qInputYea;
    begining:
    string movieName;
    string qInput;
    string qInput2;
    string qInput3;
    string qInput4;
    double rating;
    int year;
    char firstLetter;
    movieName = "The Holy Mountain";
    rating = 7.9;
    year = 1975;

    //Beginning of the fun
    cout << "Film Name(No Spaces): " << endl;
    cin >> qInput;

        //If default
        if (qInput == "TheHolyMountain") {
            cout << "Film Name: " << movieName << endl;
            cout << "Rating: " << rating << endl;
            cout << "Release Year: " << year << endl;
            query:
            cout << "Want to view another listing, or add a new one?" << endl;
            cin >> qInput2;
            if (qInput2 == "Yes"){
                goto begining;
            }else if(qInput2 == "No"){
                return 0;
            }else if (qInput2 == "Add"){
                cout << "Film callback(What will be used to find it, no spaces):" << endl;
                cin >> qInputCall;
                cout << "Film Name:" << endl;
                cin >> qInputNam;
                cout << "Rating:";
                cin >> qInputRat;
                cout << "Release Year:" << endl;
                cin >> qInputYea;
                goto begining;
            }else{
                cout << "Please answer with 'Yes', 'No', or 'Add'." << endl;
            }

        //If custom answer
        }else if (qInput == qInputCall){
            cout << "Film Name: " << qInputNam << endl;
            cout << "Rating: " << qInputRat << endl;
            cout << "Release Year: " << qInputYea << endl;
            cout << "Want to view another listing, or add a new one?" << endl;
            cin >> qInput3;
            if (qInput3 == "Yes"){
                goto begining;
            }else if(qInput3 == "No"){
                return 0;
            }else if (qInput3 == "Add"){
                cout << "Film callback(What will be used to find it, no spaces):" << endl;
                cin >> qInputCall;
                cout << "Film Name:" << endl;
                cin >> qInputNam;
                cout << "Rating:";
                cin >> qInputRat;
                cout << "Release Year:" << endl;
                cin >> qInputYea;
                goto begining;
            }else{
                cout << "Please answer with 'Yes', 'No', or 'Add'." << endl;
            }

            //False answer
            }else{
            query2:
            cout << "No such film in registry. Try another, or add a new film?" << endl;
            cin >> qInput4;
                if (qInput4 == "Yes"){
                     goto begining;
                }else if (qInput4 == "No"){
                return 0;
                }else if (qInput4 == "Add"){
                    cout << "Film callback(What will be used to find it, no spaces):" << endl;
                    cin >> qInputCall;
                    cout << "Film Name:" << endl;
                    cin >> qInputNam;
                    cout << "Rating:";
                    cin >> qInputRat;
                    cout << "Release Year:" << endl;
                    cin >> qInputYea;
                    goto begining;
                }else{
                    cout << "Please answer with 'Yes', 'No', or 'Add'." << endl;
                    goto query2;
                }
        }
    return 0;
}
